# Retail Sales Analysis & Business Performance Dashboard

**Status:** Starter project; complete the analysis and dashboard before presenting it as finished.
**Dataset:** Synthetic sample data, not real company data.

## Objective
Analyze sales revenue, profit, order volume, category and product performance, regional trends, discounts, and payment methods.

## Tools
SQL, Excel, Power BI.

## Contents
- `data/sales_data.csv` — sample sales data
- `sql/sales_analysis.sql` — practice queries
- `docs/PowerBI_dashboard_guide.md` — dashboard design and sample DAX measures
- `docs/Excel_practice.md` — formula and PivotTable practice
- `dashboard/` — add your Power BI file and screenshots when built
- `insights.md` — record verified findings

## Workflow
1. Inspect and clean data in Excel.
2. Use formulas and PivotTables.
3. Run SQL queries.
4. Build the Power BI dashboard.
5. Document insights supported by your calculations.
